from neurospark.utils import generate_mock_neuron
from neurospark.sampler import sample_neuron
from neurospark.visualize import visualize_neuron

data = generate_mock_neuron(branches=5, points_per_branch=30)
sampled = sample_neuron(data, strategy="branch_point_focus", resolution=15)
visualize_neuron(sampled)
